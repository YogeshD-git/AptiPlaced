package com.example.aptiplaced;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import com.github.barteksc.pdfviewer.PDFView;

public class qa_pdf extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qa_pdf);

        PDFView pdfView =(PDFView)findViewById(R.id.pdfView);
        pdfView.fromAsset("qa.pdf").load();
    }



}
