package com.example.aptiplaced;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;


public class MainActivity extends AppCompatActivity
{
    String[] titles={" Quantitative Aptitude"," Verbal & Non-verbal \n\tReasoning"," Current Affairs & GK"," Online Tests"};
    String[] desc={" numbers, probability, time and \n\twork.."," seating arrangments, blood relations",
            "\tcurrent affairs, basic GK..","\taptitude test.."};
    int[] images= {R.drawable.qa,R.drawable.vr,R.drawable.ca,R.drawable.ot};
    ListView lv;
    Button btn;
    EditText numText;
    String sNum;



    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        lv=(ListView)findViewById(R.id.lv);
        MyAdapter adapter =  new MyAdapter(getApplicationContext(),titles,desc,images);
        lv.setAdapter(adapter);

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                if(position==0)
                {
                    Intent i = new Intent(MainActivity.this, qa_pdf.class);
                    startActivity(i);
                }
                if(position==1)
                {
                    Intent i = new Intent(MainActivity.this, lr_pdf.class);
                    startActivity(i);
                }
                if(position==2)
                {
                    Intent i = new Intent(MainActivity.this, ca_pdf.class);
                    startActivity(i);
                }
                if(position==3)
                {
                    Intent i = new Intent(MainActivity.this, onlineTests.class);
                    startActivity(i);
                }

            }
        });




    }

    @Override
    public void onBackPressed()
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(false);
        builder.setMessage("Are you sure to exit?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                MainActivity.this.finish();
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        AlertDialog alertDialog= builder.create();
        alertDialog.show();

    }



}

class MyAdapter extends ArrayAdapter
{
    int[] imageArray;
    String[] titleArray;
    String[] descArray;

    public MyAdapter(Context context, String[] titles,String[] desc, int[] img)
    {
        super(context, R.layout.custlistview,R.id.idTitle,titles);
        this.imageArray=img;
        this.titleArray=titles;
        this.descArray=desc;

    }

    @NonNull
    @Override
    public View getView(int position,  View convertView,ViewGroup parent)
    {
        LayoutInflater inflater =(LayoutInflater)getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View row = inflater.inflate(R.layout.custlistview,parent,false);


        ImageView myImage =(ImageView) row.findViewById(R.id.idPic);
        TextView myTitle =(TextView) row.findViewById(R.id.idTitle);
        TextView myDesc =(TextView) row.findViewById(R.id.idDesc);

        myImage.setImageResource(imageArray[position]);
        myTitle.setText(titleArray[position]);
        myDesc.setText(descArray[position]);


        return row;
    }
}