package com.example.aptiplaced;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ProgressBar;

public class onlineTests extends AppCompatActivity {

    private String webAddress = "https://www.faceprep.in/aptipedia/testgym/";

   private FrameLayout frameLayout;
   private ProgressBar progressBar;
   private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_online_tests);

                 webView = (WebView)findViewById(R.id.webview);
                 progressBar = (ProgressBar)findViewById(R.id.pb);
                 frameLayout = (FrameLayout)findViewById(R.id.fl);
                progressBar.setMax(100);
                webView.setWebViewClient(new HelpClient());
                webView.setWebChromeClient(new WebChromeClient()
                {

                    public void onProgressChanged(WebView view, int progress)
                    {
                        frameLayout.setVisibility(View.VISIBLE);
                        progressBar.setProgress(progress);

                        setTitle("Loading...");

                        if(progress==100)
                        {
                            frameLayout.setVisibility(View.GONE);
                            setTitle(view.getTitle());
                        }
                        super.onProgressChanged(view,progress);

                    }
                });
                webView.getSettings().setJavaScriptEnabled(true);
                webView.setVerticalScrollBarEnabled(false);
                webView.loadUrl(webAddress);
                progressBar.setProgress(0);



    }
    private class HelpClient extends WebViewClient
    {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
          view.loadUrl(url);
          frameLayout.setVisibility(View.VISIBLE);
          return true;
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event)
    {

        if(keyCode == KeyEvent.KEYCODE_BACK)
        {
            if(webView.canGoBack())
            {
                webView.goBack();
                return true;
            }
        }
        return super.onKeyUp(keyCode, event);
    }


}
